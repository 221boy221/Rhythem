﻿using UnityEngine;
using System.Collections;

public class DonutMover : MonoBehaviour {
    private float speed = 0.1f;
    void Update() {
        transform.Translate(Vector3.left * speed);
    }
    void OnTriggerEnter2D(Collider2D wall) {
        if (wall.gameObject.tag == "deathWall") {
            Destroy(gameObject);
        }
    }
}
